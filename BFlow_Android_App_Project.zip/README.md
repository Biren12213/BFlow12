# BFlow Android App

This is the Android Studio project for BFlow, packaged around the same offline budget app.

## Included
- A–K equal categories (9.09% display, precise 100% total internally)
- Monthly income and expense tracking
- Cumulative carry-forward balances
- Local browser-style storage inside the Android app
- Import / Export Backup JSON
- No backend/database and no INTERNET permission

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Select **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

For a release APK, use **Build > Generate Signed App Bundle / APK** and create or select a signing key.

## Privacy
Budget data is kept in the app's local WebView storage. Export only writes a backup when you explicitly choose a file location. The app manifest does not request INTERNET permission.
